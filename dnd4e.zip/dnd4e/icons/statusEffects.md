The icons within the icons/statusEffects folder are by the authors of [Game-icons.net](https://game-icons.net/) are licensed under [CC BY 3.0.](https://creativecommons.org/licenses/by/3.0/legalcode).


* Blinded:		https://game-icons.net/1x1/skoll/sight-disabled.html
* Bloodied:		https://game-icons.net/1x1/lorc/drop.html
* Dazed:			https://game-icons.net/1x1/lorc/star-swirl.html
* Deafened:		https://game-icons.net/1x1/skoll/hearing-disabled.html
* Dominated:		https://game-icons.net/1x1/lorc/psychic-waves.html
* Dying:			https://game-icons.net/1x1/lorc/pummeled.html
* Dead:			https://game-icons.net/1x1/delapouite/dead-head.html
* Restrained:		https://game-icons.net/1x1/lorc/imprisoned.html
* Immobilized:	https://game-icons.net/1x1/lorc/nailed-foot.html
* Invisable:		https://game-icons.net/1x1/delapouite/invisible.html
* Petrified:		https://game-icons.net/1x1/skoll/cement-shoes.html
* Prone:			https://game-icons.net/1x1/sbed/falling.html
* Removed from:	https://game-icons.net/1x1/lorc/portal.html
* Grabbed:		https://game-icons.net/1x1/lorc/grab.html
* Slowed:			https://game-icons.net/1x1/lorc/snail.html
* Stunned:		https://game-icons.net/1x1/skoll/knockout.html
* Surprised:		https://game-icons.net/1x1/lorc/surprised.html
* Unconscious:	https://game-icons.net/1x1/lorc/sleepy.html
* Weakened:		https://game-icons.net/1x1/lorc/back-pain.html

* Marked:			https://game-icons.net/1x1/lorc/moebius-star.html

* AttackDown:		https://game-icons.net/1x1/lorc/shattered-sword.html
* AttackUp:		https://game-icons.net/1x1/lorc/blade-drag.html
* DefDown:		https://game-icons.net/1x1/lorc/cracked-shield.html
* DefUp:			https://game-icons.net/1x1/lorc/white-tower.html
* Insubstantial:	https://game-icons.net/1x1/lorc/ghost.html
* Flying:			https://game-icons.net/1x1/lorc/feathered-wing.html
* Mounted:		https://game-icons.net/1x1/delapouite/horse-head.html
* Ammo Count:		https://game-icons.net/1x1/lorc/arrow-cluster.html
* regen:			https://game-icons.net/1x1/sbed/health-increase.html
* curse:			https://game-icons.net/1x1/lorc/cursed-star.html
* oath:			https://game-icons.net/1x1/lorc/eclipse-flare.html
* Hunter Mark:	https://game-icons.net/1x1/lorc/reticule.html
* Target:			https://game-icons.net/1x1/delapouite/convergence-target.html
* OngoingDamage:	https://game-icons.net/1x1/lorc/bloody-stash.html

* Unarmed:		https://game-icons.net/1x1/skoll/drop-weapon.html
* Sleeping:		https://game-icons.net/1x1/delapouite/night-sleep.html
* Torch:			https://game-icons.net/1x1/delapouite/torch.html
* Drunk:			https://game-icons.net/1x1/lorc/pouring-chalice.html
* Sneaking:		https://game-icons.net/1x1/delapouite/robber.html

