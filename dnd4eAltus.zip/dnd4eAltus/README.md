![](https://img.shields.io/badge/Foundry-v0.8.8-informational)

## D&D 4e - Beta
* **Author**: EndlesNights#9000
* **Foundry VTT Compatibility**: 0.8.8

### Description
A beta build of D&D4e to be used via the Foundry VTT.

## Installation
* Open the Foundry application and click **"Install System"** in the **"Gane Systems"** tab.
* Paste the following link: https://raw.githubusercontent.com/EndlesNights/dnd4eBeta/dndAltus/system.json
* Click "Install"
* When creating a new Game World, select **"4th Edition Beta"** under **Game Systems**.

![image](https://user-images.githubusercontent.com/58280840/122214010-991a4d80-ce77-11eb-8b55-98f537e93ebf.png)
